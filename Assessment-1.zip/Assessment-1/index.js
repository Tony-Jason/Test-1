
function book(name,author,price){
    this.name;
    this.author;
    this.price;
}

var array = [];

$("#sherlock").on("click", function(){
    var books = new book($("#tablebook1").html(),$("#tableauthor1").html(),$("#tableprice1").html());
    
    console.log(books.name);
    array.push(books);
    addRow(books);

});
function addRow(books) {
    var item = $.parseJSON(JSON.stringify(books));
    var tr = "";
    tr += "<tr>";
    tr += "<td class='name'>";
    tr += item.name;
    tr += "</td>";
    tr += "<td class='author'>";
    tr += item.author;
    tr += "</td>";
    tr += "<td class='price'>";
    tr += item.price;
    tr += "</td>";
   
    tr += "</tr>";
    $("#tablelist > tbody").append(tr);
}
